""" App Desarrollada por Marcelo Cavieres,
    Estudiante de Ingenieria en Computacion e Informatica
    de la Universidad Andres Bello """


""" Bibliotecas """

from Tkinter import *
from tkFileDialog import *
import os
import tkMessageBox

""" Funciones """

def Abrir():
  try:
   
    a = askopenfile(mode="r")
    r = str(a)
    r = r.split("/")
    cont = 0
    for x in r:
      if ".pdf" in x:
	cont = cont + 1
    if cont == 0:
      tkMessageBox.showerror("Formato invalido", "Seleccione un archivo .pdf para borrar sus metadatos")
      return 0
    b = open("aux.pdf", mode="w")
    for x in a:
      if "/Producer" in x:
        continue
      elif "/Creator" in x:
        continue
      else:
        b.write(x)
  except TypeError:
    return 0

def Guardar():
  try:
    nombre = Nombre_Save.get()
    if ".pdf" not in nombre:
      tkMessageBox.showerror("Formato invalido","Recuerde que el nombre debe terminar en .pdf")
      return 0
    elif len(nombre)<5:
      tkMessageBox.showerror("Nombre Vacio","Ingrese un nombre valido, recuerde que debe terminar en .pdf")
      return 0
    c = askdirectory()
    comando = "mv aux.pdf " + c + "/" + nombre
    os.system(comando)
    tkMessageBox.showinfo("Nice!", ("Metadatos limpiados exitosamente, archivo guardado como " + nombre))
  except TypeError:
    return 0


""" Ventana """

nombre = ""
v0 = Tk()
v0.title("CleanPDF")
v0.geometry("500x400")
v0.resizable(width=FALSE, height=FALSE)
fondo = PhotoImage(file="Fondo1.gif")
fond = Label(v0, image=fondo)
fond.place(x=0,y=0)
Abrir_archivo = Button(v0, text="Abrir Archivo", fg="green",command=Abrir)
Abrir_archivo.place(x=200,y=145)
Nombre_Save = Entry(v0,textvariable=nombre)
Nombre_Save.place(x=165,y=300)
Guardar_archivo = Button(v0, text="Guardar Archivo",command=Guardar)
Guardar_archivo.place(x=190, y=340)
v0.mainloop()
